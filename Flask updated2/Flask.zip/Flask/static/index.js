window.onload = function () {
  var UID = sessionStorage.getItem("UID");
  document.getElementById("uid").innerHTML = UID;
};
