function credentailsValidation() {
  const userId = document.getElementById("idEmail");
  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (!userId.value.match(mailformat)) {
    alert("Invalid email address!");
  } else {
    var UID = document.getElementById("idUser").value;
    sessionStorage.setItem("UID", UID);
    window.location.replace("/index");
  }
}

function signup(){
  window.location.replace("/signup");
}